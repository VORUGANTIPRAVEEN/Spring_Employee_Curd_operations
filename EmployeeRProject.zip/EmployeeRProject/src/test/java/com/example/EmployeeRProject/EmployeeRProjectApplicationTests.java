package com.example.EmployeeRProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
